@extends('layouts.app')

@section('titulo','nosotros')

@section('contenido')
    <br>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur, quidem corporis! Natus, repellendus
        accusamus delectus alias fuga perferendis. Quidem blanditiis aliquid nobis vitae quisquam natus amet,
        sapiente mollitia. Libero, nemo.</p>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab esse eligendi enim neque provident
        odit modi sunt amet! Mollitia amet porro nostrum dolorem sunt illum ea itaque, vel molestias iure.</p>


@endsection
