@extends('layouts.app')

@section('titulo','Bienvenido')

@section('contenido')
<br>
<p> Bienevenido a mi academia</p>

@endsection
