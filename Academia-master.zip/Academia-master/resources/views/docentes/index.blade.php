@extends('layouts.app')

@section('titulo','Lista Docentes')

@section('contenido')
<br>
<br>
<br>
<p>HOLAAAAAAAAA</p>
